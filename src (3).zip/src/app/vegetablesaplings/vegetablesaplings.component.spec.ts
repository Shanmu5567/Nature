import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VegetablesaplingsComponent } from './vegetablesaplings.component';

describe('VegetablesaplingsComponent', () => {
  let component: VegetablesaplingsComponent;
  let fixture: ComponentFixture<VegetablesaplingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VegetablesaplingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VegetablesaplingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
