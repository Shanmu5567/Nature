import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegetablesaplings',
  templateUrl: './vegetablesaplings.component.html',
  styleUrls: ['./vegetablesaplings.component.css']
})
export class VegetablesaplingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
