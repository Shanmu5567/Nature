import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagenotfound404',
  templateUrl: './pagenotfound404.component.html',
  styleUrls: ['./pagenotfound404.component.css']
})
export class Pagenotfound404Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
