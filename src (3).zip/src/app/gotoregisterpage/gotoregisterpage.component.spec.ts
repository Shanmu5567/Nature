import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GotoregisterpageComponent } from './gotoregisterpage.component';

describe('GotoregisterpageComponent', () => {
  let component: GotoregisterpageComponent;
  let fixture: ComponentFixture<GotoregisterpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GotoregisterpageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GotoregisterpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
