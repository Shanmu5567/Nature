import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gotoregisterpage',
  templateUrl: './gotoregisterpage.component.html',
  styleUrls: ['./gotoregisterpage.component.css']
})
export class GotoregisterpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
