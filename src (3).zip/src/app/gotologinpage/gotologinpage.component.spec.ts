import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GotologinpageComponent } from './gotologinpage.component';

describe('GotologinpageComponent', () => {
  let component: GotologinpageComponent;
  let fixture: ComponentFixture<GotologinpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GotologinpageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GotologinpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
