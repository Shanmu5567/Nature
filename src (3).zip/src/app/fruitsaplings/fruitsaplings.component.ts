import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruitsaplings',
  templateUrl: './fruitsaplings.component.html',
  styleUrls: ['./fruitsaplings.component.css']
})
export class FruitsaplingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
