import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruitseeds',
  templateUrl: './fruitseeds.component.html',
  styleUrls: ['./fruitseeds.component.css']
})
export class FruitseedsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
