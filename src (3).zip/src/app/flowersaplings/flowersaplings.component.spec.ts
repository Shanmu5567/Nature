import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowersaplingsComponent } from './flowersaplings.component';

describe('FlowersaplingsComponent', () => {
  let component: FlowersaplingsComponent;
  let fixture: ComponentFixture<FlowersaplingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FlowersaplingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FlowersaplingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
