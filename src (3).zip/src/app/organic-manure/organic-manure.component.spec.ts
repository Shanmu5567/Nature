import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganicManureComponent } from './organic-manure.component';

describe('OrganicManureComponent', () => {
  let component: OrganicManureComponent;
  let fixture: ComponentFixture<OrganicManureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrganicManureComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrganicManureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
