import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bonsai',
  templateUrl: './bonsai.component.html',
  styleUrls: ['./bonsai.component.css']
})
export class BonsaiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
