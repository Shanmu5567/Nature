import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { BonsaiComponent } from './bonsai/bonsai.component';
import { FlowersaplingsComponent } from './flowersaplings/flowersaplings.component';
import { FruitsaplingsComponent } from './fruitsaplings/fruitsaplings.component';
import { OrganicManureComponent } from './organic-manure/organic-manure.component';
import { GardeningtoolsComponent } from './gardeningtools/gardeningtools.component';
import { VegetableseedsComponent } from './vegetableseeds/vegetableseeds.component';
import { FruitseedsComponent } from './fruitseeds/fruitseeds.component';
import { SpecialoffersComponent } from './specialoffers/specialoffers.component';
import { VegetablesaplingsComponent } from './vegetablesaplings/vegetablesaplings.component';
import { Pagenotfound404Component } from './pagenotfound404/pagenotfound404.component';
import { NodatafoundComponent } from './nodatafound/nodatafound.component';
import { GotologinpageComponent } from './gotologinpage/gotologinpage.component';
import { SubmitComponent } from './submit/submit.component';
import { LoginComponent } from './login/login.component';
import { AddtocartComponent } from './addtocart/addtocart.component';


const routes: Routes = [         
  
  {path:'home',component:HomeComponent},
  {path:'products',component:ProductsComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'contactus',component:ContactusComponent},
  {path:'feedback',component:FeedbackComponent},
  {path:'bonsai',component:BonsaiComponent},
  {path:'flowersaplings',component:FlowersaplingsComponent},
  {path:'organicmanuare',component:OrganicManureComponent},
  {path:'gardeningtools',component:GardeningtoolsComponent},
  {path:'vegetableseeds',component:VegetableseedsComponent},
  {path:'fruitseeds',component:FruitseedsComponent},
  {path:'specialoffers',component:SpecialoffersComponent},
  {path:'vegetablesaplings',component:VegetablesaplingsComponent},
  {path:'fruitsaplings',component:FruitsaplingsComponent},
  {path:'pagenotfound404',component:Pagenotfound404Component},
  {path:'nodatafound',component:NodatafoundComponent},
  {path:'gotologinpage',component:GotologinpageComponent},
  {path:'submit',component:SubmitComponent},
  {path:'login',component:LoginComponent},
  {path:'addtocart',component:AddtocartComponent},
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }