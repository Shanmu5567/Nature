import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegetableseeds',
  templateUrl: './vegetableseeds.component.html',
  styleUrls: ['./vegetableseeds.component.css']
})
export class VegetableseedsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
