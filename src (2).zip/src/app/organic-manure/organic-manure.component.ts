import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organic-manure',
  templateUrl: './organic-manure.component.html',
  styleUrls: ['./organic-manure.component.css']
})
export class OrganicManureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
