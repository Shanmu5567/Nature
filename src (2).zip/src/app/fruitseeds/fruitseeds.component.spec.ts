import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FruitseedsComponent } from './fruitseeds.component';

describe('FruitseedsComponent', () => {
  let component: FruitseedsComponent;
  let fixture: ComponentFixture<FruitseedsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FruitseedsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FruitseedsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
