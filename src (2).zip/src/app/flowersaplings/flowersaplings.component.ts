import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flowersaplings',
  templateUrl: './flowersaplings.component.html',
  styleUrls: ['./flowersaplings.component.css']
})
export class FlowersaplingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
