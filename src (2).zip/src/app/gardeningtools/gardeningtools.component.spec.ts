import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GardeningtoolsComponent } from './gardeningtools.component';

describe('GardeningtoolsComponent', () => {
  let component: GardeningtoolsComponent;
  let fixture: ComponentFixture<GardeningtoolsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GardeningtoolsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GardeningtoolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
