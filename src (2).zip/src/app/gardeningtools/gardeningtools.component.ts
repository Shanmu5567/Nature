import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gardeningtools',
  templateUrl: './gardeningtools.component.html',
  styleUrls: ['./gardeningtools.component.css']
})
export class GardeningtoolsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
