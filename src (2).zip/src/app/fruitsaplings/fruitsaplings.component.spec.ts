import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FruitsaplingsComponent } from './fruitsaplings.component';

describe('FruitsaplingsComponent', () => {
  let component: FruitsaplingsComponent;
  let fixture: ComponentFixture<FruitsaplingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FruitsaplingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FruitsaplingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
