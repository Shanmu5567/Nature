import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { BonsaiComponent } from './bonsai/bonsai.component';
import { FlowersaplingsComponent } from './flowersaplings/flowersaplings.component';
import { FruitsaplingsComponent } from './fruitsaplings/fruitsaplings.component';
import { OrganicManureComponent } from './organic-manure/organic-manure.component';
import { GardeningtoolsComponent } from './gardeningtools/gardeningtools.component';
import { VegetableseedsComponent } from './vegetableseeds/vegetableseeds.component';
import { FruitseedsComponent } from './fruitseeds/fruitseeds.component';
import { SpecialoffersComponent } from './specialoffers/specialoffers.component';
import { VegetablesaplingsComponent } from './vegetablesaplings/vegetablesaplings.component';
import { Pagenotfound404Component } from './pagenotfound404/pagenotfound404.component';
import { NodatafoundComponent } from './nodatafound/nodatafound.component';
import { GotologinpageComponent } from './gotologinpage/gotologinpage.component';
import { SubmitComponent } from './submit/submit.component';
import { LoginComponent } from './login/login.component';
import { AddtocartComponent } from './addtocart/addtocart.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductsComponent,
    ContactusComponent,
    AboutusComponent,
    NavbarComponent,
    FooterComponent,
    FeedbackComponent,
    BonsaiComponent,
    FlowersaplingsComponent,
    FruitsaplingsComponent,
    OrganicManureComponent,
    GardeningtoolsComponent,
    VegetableseedsComponent,
    FruitseedsComponent,
    SpecialoffersComponent,
    VegetablesaplingsComponent,
    Pagenotfound404Component,
    NodatafoundComponent,
    GotologinpageComponent,
    SubmitComponent,
    LoginComponent,
    AddtocartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
