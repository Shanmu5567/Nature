import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nodatafound',
  templateUrl: './nodatafound.component.html',
  styleUrls: ['./nodatafound.component.css']
})
export class NodatafoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
