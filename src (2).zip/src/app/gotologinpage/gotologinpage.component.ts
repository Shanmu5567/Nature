import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gotologinpage',
  templateUrl: './gotologinpage.component.html',
  styleUrls: ['./gotologinpage.component.css']
})
export class GotologinpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
